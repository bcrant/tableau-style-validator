class NotSignedInError(Exception):
    pass
